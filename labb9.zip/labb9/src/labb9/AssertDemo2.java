package labb9;

public class AssertDemo2 {

	public static void main(String[] args) 
	{
		int x = -1;
		assert x >= 0: "x < 0 ө.х. х-гийн утга 0-ээс бага байна! ";
		System.out.println("Өгөгдсөн тоо =: " + x);
	}

}
