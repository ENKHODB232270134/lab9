package labb9;

public class Example {

	public static void main(String[] args) {
		int age = 14;
		assert age >= 18 : "Санал өгч болохгүй";
		System.out.println("Иргэний нас нь: " + age);
	}

}
