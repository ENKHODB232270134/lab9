package labb9;

public class AssertDemo {

	public static void main(String[] args) 
	{
		int x = -1;
		assert x >= 0;

	}

}
